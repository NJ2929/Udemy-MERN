import React from 'react';
import ReactDOM from 'react-dom';

import './Backdrop.css';

//createPortal allows us to render the component where we want to in the div.
//createPortal lets you render some children into a different part of the DOM.
const Backdrop = props => {
  return ReactDOM.createPortal(
    <div className="backdrop" onClick={props.onClick}></div>,
    document.getElementById('backdrop-hook')
  );
};

export default Backdrop;
