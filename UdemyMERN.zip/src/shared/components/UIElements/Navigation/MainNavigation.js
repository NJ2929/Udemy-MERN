import React,{useState} from 'react';
import {Link} from 'react-router-dom';

import './MainNavigation.css';
import '../Navigation/MainHeader';
import MainHeader from '../Navigation/MainHeader';
import NavLinks from './NavLinks';
import SideDrawer from './SideDrawer';
import Backdrop from '../Backdrop';

const MainNavigation=(props)=> {
    const [drawerIsOpen,setDrawerIsOpen] =useState(false);
    const openDrawer= ()=>{
        setDrawerIsOpen(true);
    };

    const closerDrawer= ()=>{
        setDrawerIsOpen(false);
    };
return (
    // to return multiple root level component, we wrap it with, react. fragment.

    //ex; return 1 2; like this isnt possible in JS, so we wrap it with 
    //React.Fragment

    // && in JS, logical and.
    <React.Fragment>
        {drawerIsOpen && <Backdrop onClick={closerDrawer}/>}
         
     <SideDrawer show={drawerIsOpen}>
        <nav className="main-navigation__drawer-nav">
            <NavLinks/>
            </nav>
     </SideDrawer>
     

<MainHeader>
    <button className="main-navigation__menu_btn" onClick={openDrawer}>
        <span/>
        <span/>
        <span/>
    </button>
    <h1 className="main-navigation__title">
            <Link to='\'> Your Places </Link>
    </h1>
    <nav className="main-navigation__header-nav">
       <NavLinks/>
    </nav>
</MainHeader>
</React.Fragment>
)
};

export default MainNavigation