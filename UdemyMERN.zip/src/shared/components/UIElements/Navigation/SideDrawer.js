import React from 'react';
import ReactDom from 'react-dom';
import {CSSTransition} from 'react-transition-group';

import './SideDrawer.css'

const SideDrawer =(props)=>{
const content = 
<CSSTransition in={props.show} timeout={500} classNames="slide-in-left" mountOnEnter unmountOnExit>
<aside className="side-drawer">{props.children}</aside> 
</CSSTransition>

return ReactDom.createPortal(content,document.getElementById('drawer-hook'));
};


//createPortal allows us to render the component where we want to in the div.
export default SideDrawer;