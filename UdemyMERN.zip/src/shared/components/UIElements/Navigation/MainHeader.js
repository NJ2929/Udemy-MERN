import React from 'react';

import './MainHeader.css';

const MainHeader=(props)=>{
return <header className='main-header'>
{
    props.children // props.children, is built in- so it will take all the properties of the partent compoments
    // when this MAINHEADER is called, it will take everything insdie <MainHeader> and displays it in 
    // this compoments, from wherever, this will be called.
}

</header>
};

export default  MainHeader;
