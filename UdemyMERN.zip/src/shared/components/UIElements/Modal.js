// import React from 'react';
// import './Modal.css';
// import ReactDom from 'react-dom';



// const ModalOverlay =(props)=>{

//     const content = (
//         <div className={`modal ${props.className}`} style={props.style}> 
//             <header className={`modal__header ${props.headerClass}`}></header>
//             <h2>{props.header}</h2>

//             <form onSubmit={props.onSubmit? props.onSubmit : event=>event.preventDefault()}>


//             </form>


//         </div>
//     );
//    return  ReactDom.createPortal('',document.getElementById('modal-hook'));
// };


// const Modal =(props)=>{
    
// };

// export default Modal;