import React from 'react';
import UserLists from '../components/UserList';


const Users = () => {
  const USERS=[
   {id:'u1',name:'My Name',image:'https://picsum.photos/100',places:'3'}

  ];
  return <UserLists items={USERS}/>;
};

export default Users;
