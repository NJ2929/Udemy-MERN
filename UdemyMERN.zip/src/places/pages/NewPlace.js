import React, { useCallback, useReducer } from 'react';
import { VALIDATOR_MINLENGTH, VALIDATOR_REQUIRE } from '../../shared/util/validators';
import Input from '../../shared/components/FormElements/Input';

import Button from '../../shared/components/FormElements/Button';
import { useForm } from '../../shared/hooks/form-hook';
import './PlaceForm.css';


 //here we are using 2 properties, inputs and description and 'title' and 'description'
 // are the ids 
const NewPlace = () => {
const [formState, inputHandler]= useForm(
{
  title: {
    value:'',
    isValid:false
  },
  description:{
    value:'',
    isValid:false
  },
  address:{
    value:'',
    isValid:false
  }
},false)

  

  const placeSubmitHandler=event=>{
    event.preventDefault();
    console.log(formState.inputs); //send this to DB later
  }

  return (
  <form className="place-form" onSubmit={placeSubmitHandler}>
    <Input
    id= "title"
     element="input" 
     type="text" 
      label="Title"
      validators={[VALIDATOR_REQUIRE()]}
      onInput={inputHandler}
    errorText="Plese enter a valid title" />

<Input
  id="description"
     element="textarea" 
     type="text" 
      label="Description"
      validators={[VALIDATOR_MINLENGTH(5)]}
    errorText="Plese enter a valid description"
    onInput={inputHandler}
    />
    <Input
    id="address"
    element="input" 
    label="Address"
    validators={[VALIDATOR_REQUIRE()]}
     errorText="Plese enter a valid Address"
     onInput={inputHandler}
     
    />


    <Button type="submit" disabled={!formState.isValid}>ADD PLACE</Button>
  </form>
  )
};

export default NewPlace;