import React from 'react';
import PlaceList from '../components/PlaceList';
import { useParams } from 'react-router-dom';

const DUMMY_PLACES= [
    {
        id: 'p1',
        title: 'Landscapes',
        description:'Beautiful landscape of the Earth',
        imageURL: 'https://www.istockphoto.com/photo/arambol-beach-goa-gm469852152-61815842?utm_source=pixabay&utm_medium=affiliate&utm_campaign=SRP_image_sponsored&utm_content=https%3A%2F%2Fpixabay.com%2Fimages%2Fsearch%2Fbeach%2F&utm_term=beach',
        address:'abc addrress 38',
        location: {
            lat: 30.23343,
            lng: -73.93434
        },
        creator: 'u1'
    },
    {
        id: 'p2',
        title: 'Car',
        description:'Beautiful Carsh',
        imageURL: 'https://www.pexels.com/photo/blue-bmw-sedan-near-green-lawn-grass-170811/',
        address:'abc addrress 38',
        location: {
            lat: 32.23343,
            lng: -73.93434
        },
        creator: 'u2'
    }
    ];

    
const UserPlaces = (props) => {
const params= useParams();
const userId= params.userId;
const loadedPlaces  =DUMMY_PLACES.filter(place=> place.creator===userId);
// as  filter will return an array
  return <PlaceList items={loadedPlaces}/>
};

export default UserPlaces;