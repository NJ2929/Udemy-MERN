import React from 'react';
//import ReactDOM from 'react-dom';
import { createRoot } from 'react-dom/client';

import './index.css';
import App from './App';
//ReactDOM.render(<App />, document.getElementById('root')); //   THIS WAS USED IN PREVIOUD REACT VERSIONS
createRoot(document.getElementById('root')).render(<App/>); // THIS IS CURRENTLY USED- IN REACT JS 18
//createRoot(<App />,document.getElementById('root'));
